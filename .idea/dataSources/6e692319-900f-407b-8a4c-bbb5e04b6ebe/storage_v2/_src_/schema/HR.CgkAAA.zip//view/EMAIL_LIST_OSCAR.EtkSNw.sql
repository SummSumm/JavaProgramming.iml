create view EMAIL_LIST_OSCAR as
select substr(first_name,0,1)||'.'||substr(last_name,0,1) as "initials",
       first_name||' '||last_name as "full_name", lower(email||'@gmail.com') as "full_email"
from employees
/

